
public class LinkedListException extends Throwable {
	private static final long serialVersionUID = 1L;

	public LinkedListException() {
	}

	public LinkedListException(String message) {
		super(message);
	}
}
